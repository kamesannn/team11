#include <iostream>
#include <fstream>
#include <string>
using namespace std;

 

//structure definition
struct Contacts
{
    char first_name[51];
    char last_name[51];
    char address_Line1[51];
    char address_Line2[51];
    char phone[14];
};

 

//Declaring functions
int menu();
void addRecord(fstream& people);
void searchRecord(fstream& people);

Contacts c;
fstream people;

 

int main()
{
    int choice;

 

    do
    {
        choice = menu();
        switch (choice)
        {
        case 1:
        {
            addRecord(people); break;
        }
        case 2:
        {
            searchRecord(people); break;
        }
        case 3:
        {
            cout << "\nExiting the search program..."; break;
        }
        default:
        {
            cout << "\nPlease enter a valid choice!";
        }
        }

 

    } while (choice != 3);

    cout << "\n\n";

 

    return 0;
}

 

int menu()
{
    int choice;

 

    cout << "\n\nWelcome to Contacts List:\n";
    cout << "\n1. Add contact to file";
    cout << "\n2. Search contact in file";
    cout << "\n3. Quit";
    cout << "\nPlease select an option from the menu: ";
    cin >> choice;

 

    return choice;
}

void addRecord(fstream& people)
{
    char answer = 'y';

 

    do
    {
        cout << "\nEnter person information: ";

 

        cin.ignore();
        cout << "\nFirst Name: ";
        cin.getline(c.first_name, 51);
        cout << "Last Name: ";
        cin.getline(c.last_name, 51);
        cout << "Address line 1: ";
        cin.getline(c.address_Line1, 51);
        cout << "Address line 2: ";
        cin.getline(c.address_Line2, 51);
        cout << "Phone: ";
        cin.getline(c.phone, 14);

 

        //write to file
        people.open("contact.txt", ios::out | ios::app | ios::binary); //out mode to write the content
        people << c.first_name << endl;
        people << c.last_name << endl;
        people << c.address_Line1 << endl;
        people << c.address_Line2 << endl;
        people << c.phone << endl;

 

        people.close(); // save and close the file

 

        //continue?
        cout << "Do you want to enter another record ? ";
        cin >> answer;

 

    } while (answer == 'y' || answer == 'Y');
}

 void searchRecord(fstream& people)
{
    char s_name[51];

 

    cin.ignore();
    cout << "\nEnter the first name of person to retrieve the records: ";
    cin.getline(s_name, 51);

 

    //open file
    people.open("contact.txt", ios::in | ios::binary); //opening in a read mode

 

    
    if (people.is_open())
    {
        while (!people.eof()) // end of file
        {
            people.getline(c.first_name, 51);
            people.getline(c.last_name, 51);
            people.getline(c.address_Line1, 51);
            people.getline(c.address_Line2, 51);
            people.getline(c.phone, 14);

 

            //check
            if (strcmp(c.first_name, s_name) == 0) //searching the record by first name
            {
                cout << "First Name: " << c.first_name << endl;
                cout << "Last Name: " << c.last_name << endl;
                cout << "Address line 1: " << c.address_Line1 << endl;
                cout << "Address line 2: " << c.address_Line2 << endl;
                cout << "Phone: " << c.phone << endl;
                cout << "\nThat's all the information in the file for the search key provided!";
                break;
            }
            else
            {
                cout << "\nNo record found in the file for the search key provided!";
                break;
            }
        }
    }
    else
    {
        cout << "\nFile unable to access ....";

 

    }

 

    people.close();
}





            
            
            

 
